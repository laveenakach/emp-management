

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow rounded">
        <div class="card-header text-white d-flex justify-content-between align-items-center" style="background-color: rgb(26 24 57) !important;">
            <h4 class="mb-0">Employee Details</h4>
            <a href="<?php echo e(route('employer.employees.index')); ?>" class="btn btn-light btn-sm">← Back to List</a>
        </div>

        <div class="card-body">
                        <!-- Profile Photo -->
            <div class="row mb-4">
                <div class="col-md-2 text-center">
                    <?php if($user->photo): ?>
                    <img src="<?php echo e(asset('uploads/profile_photos/' . $user->photo)); ?>" class="rounded-circle shadow" style="width: 100px; height: 100px; object-fit: cover;" alt="Profile Photo">
                    <?php else: ?>
                    <img src="<?php echo e(asset('default-user.png')); ?>" class="rounded-circle shadow" style="width: 100px; height: 100px;" alt="Default">
                    <?php endif; ?>
                </div>
                <div class="col-md-10 d-flex align-items-center">
                    <h5 class="mb-0">Hello, <strong><?php echo e($user->name); ?></strong> 👋</h5>
                </div>
            </div>

            <!-- 4-column Table -->
            <table class="table table-bordered table-striped">
                <tr>
                    <th style="width: 15%; background-color: #f8f9fa;">Employee ID</th>
                    <td style="width: 35%;"><?php echo e($user->empuniq_id); ?></td>
                    <th style="width: 15%; background-color: #f8f9fa;">Email</th>
                    <td style="width: 35%;"><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <th style="background-color: #f8f9fa;">Mobile No</th>
                    <td><?php echo e($user->mobile_no); ?></td>
                    <th style="background-color: #f8f9fa;">Experience</th>
                    <td><?php echo e($user->experience); ?></td>
                </tr>
                <tr>
                    <th style="background-color: #f8f9fa;">City</th>
                    <td><?php echo e($user->city); ?></td>
                    <th style="background-color: #f8f9fa;">Location</th>
                    <td><?php echo e($user->location); ?></td>
                </tr>
                <tr>
                    <th style="background-color: #f8f9fa;">Aadhar Card</th>
                    <td><?php echo e($user->aadhar_card); ?></td>
                    <th style="background-color: #f8f9fa;">PAN Card</th>
                    <td><?php echo e($user->pan_card); ?></td>
                </tr>
                <tr>
                    <th style="background-color: #f8f9fa;">Bank Account</th>
                    <td><?php echo e($user->bank_account); ?></td>
                    <th style="background-color: #f8f9fa;">IFSC Code</th>
                    <td><?php echo e($user->ifsc_code); ?></td>
                </tr>
                <tr>
                    <th style="background-color: #f8f9fa;">Department</th>
                    <td><?php echo e($user->department ?? 'N/A'); ?></td>
                    <th style="background-color: #f8f9fa;">Designation</th>
                    <td><?php echo e($user->designation_id ?? 'N/A'); ?></td>
                </tr>
                <tr>
                    <th style="background-color: #f8f9fa;">Role</th>
                    <td><?php echo e(ucfirst($user->role)); ?></td>
                    <th style="background-color: #f8f9fa;">Address</th>
                    <td><?php echo e($user->address); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/employer/employees/show.blade.php ENDPATH**/ ?>