

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow rounded">
        <div class="card-header text-white d-flex justify-content-between align-items-center" style="background-color: rgb(26 24 57) !important;">
            <h4 class="mb-0">Invoice Details</h4>
            <a href="<?php echo e(route('candidates.invoices.index')); ?>" class="btn btn-light btn-sm">← Back to List</a>
        </div>

        <div class="card-body">
            
            <h5 class="fw-bold mb-3">Invoice Info</h5>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">Invoice No</th>
                    <td><?php echo e($invoice->invoice_no); ?></td>
                    <th>Invoice Date</th>
                    <td><?php echo e(\Carbon\Carbon::parse($invoice->invoice_date)->format('d M Y')); ?></td>
                </tr>
                <tr>
                    <th>Due Date</th>
                    <td><?php echo e($invoice->due_date ? \Carbon\Carbon::parse($invoice->due_date)->format('d M Y') : ''); ?></td>
                    <th>Status</th>
                    <td>
                        <span class="badge bg-<?php echo e($invoice->status == 'paid' ? 'success' : 'warning'); ?>">
                            <?php echo e(ucfirst($invoice->status)); ?>

                        </span>
                    </td>
                </tr>
            </table>

            
            <h5 class="fw-bold mt-4 mb-3">Candidate Info</h5>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">Name</th>
                    <td><?php echo e($invoice->candidate->name); ?></td>
                    <th>Email</th>
                    <td><?php echo e($invoice->candidate->email); ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo e($invoice->candidate->phone); ?></td>
                    <th>GST Number</th>
                    <td><?php echo e($invoice->candidate->gst_number); ?></td>
                </tr>
                
                <tr>
                    <th>Bank Account</th>
                    <td><?php echo e($invoice->candidate->bank_account_number); ?> (IFSC: <?php echo e($invoice->candidate->ifsc_code); ?>)</td>
                    <th>Address</th>
                    <td><?php echo e($invoice->candidate->address); ?></td>
                </tr>
            </table>

            
            <h5 class="fw-bold mt-4 mb-3">Service Items</h5>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Description</th>
                        <th class="text-center">Qty</th>
                        <th class="text-end">Rate (₹)</th>
                        <th class="text-end">Amount (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $subtotal = 0; ?>
                    <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <td class="text-center"><?php echo e($item->qty); ?></td>
                            <td class="text-end"><?php echo e(number_format($item->rate, 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format($item->amount, 2)); ?></td>
                        </tr>
                        <?php $subtotal += $item->amount; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
            <h5 class="fw-bold mt-4 mb-3">Summary</h5>
            <table class="table table-bordered w-50 ms-auto">
                <tr>
                    <th width="40%">Subtotal</th>
                    <td class="text-end">₹<?php echo e(number_format($subtotal, 2)); ?></td>
                     <th>Discount</th>
                    <td class="text-end">₹<?php echo e(number_format($subtotal * $invoice->discount / 100, 2)); ?></td>
                </tr>
                <tr>
                    <th>CGST (<?php echo e($invoice->cgst_percent); ?>%)</th>
                    <td class="text-end">₹<?php echo e(number_format($subtotal * $invoice->cgst_percent / 100, 2)); ?></td>
                    <th>SGST (<?php echo e($invoice->sgst_percent); ?>%)</th>
                    <td class="text-end">₹<?php echo e(number_format($subtotal * $invoice->sgst_percent / 100, 2)); ?></td>
                </tr>
                
                <tr>
                    <th>GST (<?php echo e($invoice->gst_percent); ?>%)</th>
                    <td class="text-end">₹<?php echo e(number_format($subtotal * $invoice->gst_percent / 100, 2)); ?></td>
                    <th>Convenience Fees (<?php echo e($invoice->convenience_fees); ?>%)</th>
                    <td class="text-end">₹<?php echo e(number_format($subtotal * $invoice->convenience_fees / 100, 2)); ?></td>
                </tr>
               
                <tr class="table-light fw-bold">
                    <th></th>
                    <td class="text-end"></td>
                    <th>Grand Total</th>
                    <td class="text-end">₹<?php echo e(number_format($invoice->total_amount, 2)); ?></td>
                </tr>
            </table>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/candidates/invoices/show.blade.php ENDPATH**/ ?>