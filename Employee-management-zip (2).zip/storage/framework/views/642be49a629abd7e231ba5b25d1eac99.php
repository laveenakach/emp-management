

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-8">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary"><?php echo e(isset($Client) ? 'Edit Client' : 'Create Client'); ?></h2>
                <a href="javascript:void(0);" onclick="window.history.back();" class="btn btn-outline-secondary rounded-pill">
                    <i class="bi bi-arrow-left"></i> Back to List
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success shadow-sm"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger shadow-sm">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-4">
                    <form method="POST" action="<?php echo e($url); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($client)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label fw-semibold">Name<span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" value="<?php echo e(old('name', $client->name ?? '')); ?>" class="form-control rounded-pill" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="email" value="<?php echo e(old('email', $client->email ?? '')); ?>" class="form-control rounded-pill" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label fw-semibold">Phone <span class="text-danger">*</span></label>
                                <input type="text" name="phone" id="phone" value="<?php echo e(old('phone', $client->phone ?? '')); ?>" class="form-control rounded-pill" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="gstin" class="form-label fw-semibold">GST Number</label>
                                <input type="text" name="gstin" id="gstin" value="<?php echo e(old('gstin', $client->gstin ?? '')); ?>" class="form-control rounded-pill">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="bank_account" class="form-label fw-semibold">Bank Account Number</label>
                                <input type="text" name="bank_account" id="bank_account" value="<?php echo e(old('bank_account', $client->bank_account ?? '')); ?>" class="form-control rounded-pill">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="ifsc_code" class="form-label fw-semibold">IFSC Code</label>
                                <input type="text" name="ifsc_code" id="ifsc_code" value="<?php echo e(old('ifsc_code', $client->ifsc_code ?? '')); ?>" class="form-control rounded-pill">
                            </div>

                            <div class="col-md-12 mb-3">
                                <label for="address" class="form-label fw-semibold">Address</label>
                                <textarea name="address" id="address" class="form-control rounded-3" rows="3"><?php echo e(old('address', $client->address ?? '')); ?></textarea>
                            </div>

                            <div class="mb-3 col-md-12">
                                <label for="project_requirement" class="form-label fw-semibold">📎 Project Requirement PDF (optional, Max 5MB)</label>
                                <input type="file" id="project_requirement" name="project_requirement" class="form-control" accept="application/pdf">
                                <?php $__errorArgs = ['project_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(isset($client->project_requirement)): ?>
                                <div class="mt-2">
                                    <a href="<?php echo e(asset($client->project_requirement)); ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-paperclip me-1"></i> View Current File
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="text-end mt-4">
                            <button type="submit" class="btn btn-success rounded-pill px-5 py-2">
                                <i class="bi bi-save me-1"></i> <?php echo e(isset($client) ? 'Update' : 'Save'); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/accounts/clients/create.blade.php ENDPATH**/ ?>