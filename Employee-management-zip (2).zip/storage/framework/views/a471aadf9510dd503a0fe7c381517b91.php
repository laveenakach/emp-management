

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow rounded">
        <div class="card-header text-white d-flex justify-content-between align-items-center" style="background-color: rgb(26 24 57) !important;">
            <h4 class="mb-0">Candidate Details</h4>
            <a href="<?php echo e(route('candidates.index')); ?>" class="btn btn-light btn-sm">← Back to List</a>
        </div>

        <div class="card-body">
            <table class="table table-bordered table-striped">
                 <tr>
                    <th width="30%">Candidate ID</th>
                    <td><?php echo e($candidate->candidate_id); ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?php echo e($candidate->name); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo e($candidate->email); ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo e($candidate->phone); ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><?php echo e($candidate->address); ?></td>
                </tr>
                <tr>
                    <th>GST Number</th>
                    <td><?php echo e($candidate->gst_number); ?></td>
                </tr>
                <tr>
                    <th>Bank Account</th>
                    <td><?php echo e($candidate->bank_account_number); ?></td>
                </tr>
                <tr>
                    <th>IFSC Code</th>
                    <td><?php echo e($candidate->ifsc_code); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/candidates/show.blade.php ENDPATH**/ ?>