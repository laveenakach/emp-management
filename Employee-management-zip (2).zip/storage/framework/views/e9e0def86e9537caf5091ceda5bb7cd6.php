

<?php $__env->startSection('content'); ?>


<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary"><?php echo e(isset($Bill) ? 'Edit' : 'Create'); ?> Bill</h2>
                <a href="javascript:void(0);" onclick="window.history.back();" class="btn btn-outline-secondary rounded-pill">
                    <i class="bi bi-arrow-left"></i> Back to List
                </a>
            </div>

            <?php if(session('success')): ?>
            <div class="alert alert-success shadow-sm"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger shadow-sm">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-4">
                    <form method="POST" action="<?php echo e(isset($Bill) ? route('billings.update', $Bill->id) : route('billings.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($Bill)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                        <div class="mb-3">
                            <label>Client</label>
                            <select name="client_id" class="form-control" required>
                                <option value="">-- Select Client --</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($client->id); ?>" <?php echo e(old('client_id', $Bill->client_id ?? '') == $client->id ? 'selected' : ''); ?>>
                                    <?php echo e($client->name); ?> (<?php echo e($client->CLTuniq_id); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label>Bill Number</label>
                                <input type="text" id="bill_number" name="bill_number" value="<?php echo e(old('bill_number', $Bill->bill_number ?? '')); ?>" class="form-control" readonly required>
                            </div>
                            <div class="col">
                                <label>Bill Date</label>
                                <input type="date" name="bill_date" value="<?php echo e(old('bill_date', $Bill->bill_date ?? '')); ?>" class="form-control" required>
                            </div>
                            <div class="col">
                                <label>Due Date</label>
                                <input type="date" name="due_date" value="<?php echo e(old('due_date', $Bill->due_date ?? '')); ?>" class="form-control">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <!-- <div class="col">
                                <label>Tax (%)</label>
                                <input type="number" step="0.01" name="tax_percent" value="<?php echo e(old('tax_percent', $Bill->tax_percent ?? '18')); ?>" class="form-control" required>
                            </div> -->


                            <label>Tax (%)</label>

                            <div class="col-md-2">
                                <label><input type="checkbox" name="gst" value="18"
                                        <?php echo e(old('gst', $Bill->gst_percent ?? 0) > 0 ? 'checked' : ''); ?>> GST 18%</label>
                            </div>
                            <div class="col-md-2">
                                <label><input type="checkbox" name="cgst" value="9"
                                        <?php echo e(old('cgst', $Bill->cgst_percent ?? 0) > 0 ? 'checked' : ''); ?>> CGST 9%</label>
                            </div>
                            <div class="col-md-2">
                                <label><input type="checkbox" name="sgst" value="9"
                                        <?php echo e(old('sgst', $Bill->sgst_percent ?? 0) > 0 ? 'checked' : ''); ?>> SGST 9%</label>
                            </div>


                            <div class="col-md-4">
                                <label>Status</label>
                                <select name="status" class="form-control" required>
                                    <?php $status = old('status', $Bill->status ?? 'Pending'); ?>
                                    <option value="Pending" <?php echo e($status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="Paid" <?php echo e($status == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                                    <option value="Overdue" <?php echo e($status == 'Overdue' ? 'selected' : ''); ?>>Overdue</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="bill_notes" class="form-control" rows="3"><?php echo e(old('bill_notes', $Bill->bill_notes ?? '')); ?></textarea>
                            </div>
                        </div>

                        <h5>Bill Items</h5>
                        <table class="table" id="itemsTable">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Qty</th>
                                    <th>Rate</th>
                                    <th>
                                        <button type="button" class="btn btn-sm btn-primary" onclick="addItem()">+</button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $items = old('items', isset($Bill) ? $Bill->items : [['description' => '', 'quantity' => '', 'rate' => '']]);
                                ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input type="text" name="items[<?php echo e($index); ?>][description]" class="form-control" value="<?php echo e($item['description'] ?? ''); ?>" required></td>
                                    <td><input type="number" name="items[<?php echo e($index); ?>][quantity]" class="form-control" value="<?php echo e($item['quantity'] ?? ''); ?>" required></td>
                                    <td><input type="number" name="items[<?php echo e($index); ?>][rate]" class="form-control" value="<?php echo e($item['rate'] ?? ''); ?>" required></td>
                                    <td>
                                        <?php if($loop->first): ?>
                                        <!-- No remove button on first item -->
                                        <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('tr').remove()">X</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <button type="submit" class="btn btn-success"><?php echo e(isset($Bill) ? 'Update' : 'Create'); ?> Bill</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    let itemIndex = {
        {
            count($items)
        }
    };

    function addItem() {
        const table = document.getElementById('itemsTable').getElementsByTagName('tbody')[0];
        const row = table.insertRow();
        row.innerHTML = `
            <td><input type="text" name="items[${itemIndex}][description]" class="form-control" required></td>
            <td><input type="number" name="items[${itemIndex}][quantity]" class="form-control" required></td>
            <td><input type="number" name="items[${itemIndex}][rate]" class="form-control" required></td>
            <td><button type="button" class="btn btn-sm btn-danger" onclick="this.closest('tr').remove()">X</button></td>
        `;
        itemIndex++;
    }
</script>


<script>
    function generateBillNumber(clientId) {
        if (!clientId) return;

        const now = new Date();
        const year = now.getFullYear().toString().substr(-2);
        const month = (now.getMonth() + 1).toString().padStart(2, '0');
        const day = now.getDate().toString().padStart(2, '0');
        const random = Math.floor(1000 + Math.random() * 9000); // Random 4-digit

        const billNumber = `BILL-${clientId}-${year}${month}${day}-${random}`;
        document.getElementById('bill_number').value = billNumber;
    }

    document.querySelector('select[name="client_id"]').addEventListener('change', function() {
        generateBillNumber(this.value);
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/accounts/billing/create.blade.php ENDPATH**/ ?>