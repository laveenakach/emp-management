

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow rounded">
        <div class="card-header text-white d-flex justify-content-between align-items-center" style="background-color: rgb(26 24 57) !important;">
            <h4 class="mb-0">Client Details</h4>
            <a href="<?php echo e(route('accounts.clients.index')); ?>" class="btn btn-light btn-sm">← Back to List</a>
        </div>

        <div class="card-body">
            <table class="table table-bordered table-striped">
                <tr>
                    <th width="30%">Client Unique ID</th>
                    <td><?php echo e($client->CLTuniq_id); ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?php echo e($client->name); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo e($client->email); ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo e($client->phone); ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><?php echo e($client->address); ?></td>
                </tr>
                <tr>
                    <th>GSTIN</th>
                    <td><?php echo e($client->gstin); ?></td>
                </tr>
                <tr>
                    <th>Bank Account</th>
                    <td><?php echo e($client->bank_account); ?></td>
                </tr>
                <tr>
                    <th>IFSC Code</th>
                    <td><?php echo e($client->ifsc_code); ?></td>
                </tr>
                <tr>
                    <th>Project Requirement (PDF)</th>
                    <td>
                        <?php if($client->project_requirement): ?>
                            <a href="<?php echo e(asset($client->project_requirement)); ?>" class="btn btn-sm btn-outline-info" target="_blank">
                                <i class="bi bi-file-earmark-pdf"></i> View PDF
                            </a>
                        <?php else: ?>
                            <span class="text-muted">Not Uploaded</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/accounts/clients/show.blade.php ENDPATH**/ ?>