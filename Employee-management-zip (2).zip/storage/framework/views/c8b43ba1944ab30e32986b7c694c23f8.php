
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary"><?php echo e(isset($quotation) ? 'Edit' : 'Create'); ?> Quotation</h2>
                <a href="javascript:void(0);" onclick="window.history.back();" class="btn btn-outline-secondary rounded-pill">
                    <i class="bi bi-arrow-left"></i> Back to List
                </a>
            </div>

            <?php if(session('success')): ?>
            <div class="alert alert-success shadow-sm"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger shadow-sm">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-4">
                    <form action="<?php echo e(isset($quotation) ? route('quotations.update', $quotation->id) : route('quotations.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($quotation)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Client</label>
                                <select name="client_id" class="form-control" required>
                                    <option value="">-- Select Client --</option>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>" <?php echo e(old('client_id', $quotation->client_id ?? '') == $client->id ? 'selected' : ''); ?>>
                                        <?php echo e($client->name); ?> (<?php echo e($client->CLTuniq_id); ?>)
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Quotation Number</label>
                                <input type="text" id="quotation_number" name="quotation_number" class="form-control" value="<?php echo e(old('quotation_number', $quotation->quotation_number ?? '')); ?>" readonly required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Quotation Date</label>
                                <input type="date"
                                    name="quotation_date"
                                    class="form-control"
                                    value="<?php echo e(old('quotation_date', isset($quotation->quotation_date) ? \Carbon\Carbon::parse($quotation->quotation_date)->format('Y-m-d') : date('Y-m-d'))); ?>"
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-control" required>
                                    <?php $__currentLoopData = ['Draft', 'Sent', 'Accepted', 'Rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php echo e(old('status', $quotation->status ?? 'Draft') == $status ? 'selected' : ''); ?>>
                                        <?php echo e($status); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="3"><?php echo e(old('notes', $quotation->notes ?? '')); ?></textarea>
                        </div>

                        <hr>
                        <h5 class="text-primary">Services</h5>

                        <div id="item-container">
                            <?php
                            $items = old('items', isset($quotation) ? $quotation->items->toArray() : [['service_name' => '', 'description' => '', 'quantity' => '', 'rate' => '', 'amount' => '']]);
                            ?>

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mb-2 item-row">
                                <div class="col-md-3">
                                    <input type="text" name="items[<?php echo e($index); ?>][service_name]" class="form-control" placeholder="Service Name" value="<?php echo e($item['service_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="text" name="items[<?php echo e($index); ?>][description]" class="form-control" placeholder="Description" value="<?php echo e($item['description'] ?? ''); ?>">
                                </div>
                                <div class="col-md-1">
                                    <input type="number" name="items[<?php echo e($index); ?>][quantity]" class="form-control qty" placeholder="Qty" value="<?php echo e($item['quantity'] ?? ''); ?>" min="1" required>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="items[<?php echo e($index); ?>][rate]" class="form-control rate" placeholder="Unit Price" value="<?php echo e($item['rate'] ?? ''); ?>" min="0" required>
                                </div>
                                <div class="col-md-3 d-flex">
                                    <input type="number" name="items[<?php echo e($index); ?>][amount]" class="form-control amount" placeholder="amount" value="<?php echo e($item['amount'] ?? ''); ?>" readonly>
                                    <button type="button" class="btn btn-danger ms-1 remove-item">&times;</button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mb-3">
                            <button type="button" id="add-item" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-plus"></i> Add Services
                            </button>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-success px-4">Save Quotation</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

<script>
    $(document).ready(function () {
        $('#quotation_date').datepicker({
            format: "dd-mm-yyyy",
            autoclose: true,
            todayHighlight: true
        });
    });
</script>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        let itemIndex = <?php echo json_encode(isset($items) ? count($items) : 0, 15, 512) ?>;

        // Your existing JS code here, e.g.:
        function calculateTotal(row) {
            const qty = parseFloat(row.querySelector('.qty').value) || 0;
            const price = parseFloat(row.querySelector('.rate').value) || 0;

            const baseAmount = qty * price;
            const gst = baseAmount * 0.18;
            const totalWithGst = baseAmount + gst;

            row.querySelector('.amount').value = baseAmount.toFixed(2);

            // row.querySelector('.total').value = (qty * price).toFixed(2);
        }

        document.getElementById('add-item').addEventListener('click', function() {
            let rowHtml = `
            <div class="row mb-2 item-row">
                <div class="col-md-3">
                    <input type="text" name="items[${itemIndex}][service_name]" class="form-control" placeholder="Service Name" required>
                </div>
                <div class="col-md-3">
                    <input type="text" name="items[${itemIndex}][description]" class="form-control" placeholder="Description">
                </div>
                <div class="col-md-1">
                    <input type="number" name="items[${itemIndex}][quantity]" class="form-control qty" placeholder="Qty" min="1" required>
                </div>
                <div class="col-md-2">
                    <input type="number" name="items[${itemIndex}][rate]" class="form-control rate" placeholder="Rate" min="0" required>
                </div>
                <div class="col-md-3 d-flex">
                    <input type="number" name="items[${itemIndex}][amount]" class="form-control amount" placeholder="Amount " readonly>
                    <button type="button" class="btn btn-danger ms-1 remove-item">&times;</button>
                </div>
            </div>`;

            const container = document.getElementById('item-container');
            container.insertAdjacentHTML('beforeend', rowHtml);

            const newRow = container.lastElementChild;
            newRow.querySelector('.qty').addEventListener('input', () => calculateTotal(newRow));
            newRow.querySelector('.rate').addEventListener('input', () => calculateTotal(newRow));

            itemIndex++;
        });

        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('remove-item')) {
                e.target.closest('.item-row').remove();
            }
        });

        // Attach calculateTotal listeners to existing rows
        document.querySelectorAll('.item-row').forEach(row => {
            row.querySelector('.qty').addEventListener('input', () => calculateTotal(row));
            row.querySelector('.rate').addEventListener('input', () => calculateTotal(row));
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const clientSelect = document.querySelector('select[name="client_id"]');
        const quotationInput = document.getElementById('quotation_number');

        clientSelect.addEventListener('change', function() {
            const clientId = this.value;
            if (!clientId) return;

            const now = new Date();
            const year = now.getFullYear().toString().slice(-2);
            const month = (now.getMonth() + 1).toString().padStart(2, '0');
            const day = now.getDate().toString().padStart(2, '0');
            const random = Math.floor(1000 + Math.random() * 9000);

            const quotationNumber = `QT-${clientId}-${year}${month}${day}-${random}`;
            quotationInput.value = quotationNumber;
        });
    });
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-Management-Webapp\resources\views/accounts/quotation/create.blade.php ENDPATH**/ ?>